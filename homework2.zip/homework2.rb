# Ruby function to replace each number with a string if their value meets a when parameter
def fizzbuzz(num) 						       # Defines a method with one variable
  case  								             # Takes a variable and does different things depending on its value
  									
  										               # The next three lines test if a number is evenly divisible by 3, 5, or both(15) (no remainder)
  when num % 3 == 0 then "FizzBuzz"	 # If by 15, replaces the number with "FizzBuzz" string and passes it to the method fizz_buzz_to
  when num % 5  == 0 then "Fizz"		 # Same as above for 3, replaces with "Fizz"
  when num % 7  == 0 then "Buzz"		 # Same as above for 5, replaces with "Buzz"
  else num 								           # Numbers that fail the above retain their value
  end 									             # Ends the case statement
end 									               # Ends the fizzbuzz method

def fizz_buzz_to(limit)					     # Method to return each of the fizzbuzz values
  1.upto(limit).each do |num|		     # Sends each num within the defined range to the fizzbuzz method  
    puts fizzbuzz(num)					     # Prints the results of fizzbuzz to screen
  end 									             # End of the body of the method
end 									               # End of the method

limit = fizz_buzz_to(50) 				     # Passes a value of 50 into fizz_buzz_to test both methods