class Homework							# Creates class Homework
   def shout							# Defines a function to capitalize a string
	   self.upcase					# Calls the method on a string

   end
end

puts "Hello! Nice to see you. :)".upcase	# Calls the method on a string and prints it in capital letters