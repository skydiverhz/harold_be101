
1. What is an "instance variable"? See if you can find and explanation using google.

Instance variable is the variable declared inside a class, but outside a method, constructor or any block. 
It begins with an “@”, is something created with a “new”, and can be referenced by any method in the class instance.

************************
2. Use online ruby documentation (ruby-doc.org) to describe a method of the Integer class.

abs: Returns the absolute value of num.