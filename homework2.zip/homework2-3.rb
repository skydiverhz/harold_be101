# I could not get the second method to print 
class Homework					# Creates class Homework
	def shout					# Defines a function to capitalize a string
	   self.upcase				# Calls the method on a string
	end    						# End of method

	print "Hello! Nice to see you. :)".upcase	# Calls the method on a string and prints it in capital letters

	def repeat_string(text, num)
		text = ("Did I say Hello?")
		num = (5)
		print text * n
	end
end
