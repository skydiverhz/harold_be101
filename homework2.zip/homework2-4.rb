# Does not work
def merge_holiday_date(hol_str, date_str)
	holhash = hol_str.zip(date_str).to_holhash
end

puts "#{hol_str}:#{date_str}"	

hol_str = ["New Year's Day", "Martin Luther King Day", "Presidents' Day", "Memorial Day", "Independence Day", "Labor Day", "Columbus Day", "Veterans Day", "Thanksgiving Day", "Christmas Day"]
date_str = ["01/01/2012", "01/18/2016", "02/15/2016", "05/30/2016", "07/04/2016", "09/05/2016", "10/10/2016", "11/11/2016", "11/24/2016", "12/25/2016"]